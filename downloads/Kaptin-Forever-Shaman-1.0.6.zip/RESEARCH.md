# Forever Shaman: leveling and normal-dungeon evidence

Checked 14 November 2026. This is a source review and a practical policy recommendation, not a simulation result or an in-game validation. No simulations were run for this research.

## 16 November: main-hand imbue application in 1.0.2

The retained current [native Enhancement profile](https://auth.simia.pro/data/forever/rotation_7_ENHANCEMENT.yaml) describes ordinary weapon-imbue actions as main-hand casts and uses Windfury > Flametongue > Rockbiter, checking `!mainhand.enchant.up`. The same-day [expression catalog](https://auth.simia.pro/rotation/expression-catalog.json) documents `weapon.id` and the no-underscore `mainhand.enchant.up/remains/id` fields. Enchant IDs are separate from spell IDs. Together these establish the ordinary main-hand route without a slot-target macro. The initial release's manual-only decision is superseded for the main hand.

The local current Forever dump `../../simc-forever/SpellDataDump/shaman.txt` lists initial training at Rockbiter level 1, Flametongue level 10 and Windfury level 30. Actual learned spells, not level, govern the profile. Windfury cast ranks are 8232/8235/10486/16362; Flametongue cast ranks are 8024/8027/8030/16339/16341/16342. Same-name Windfury proc rows are not cast ranks. Named/native action resolution and `.known` rank metadata are separate: the preferred native cast retains its normal availability checks, while alias-plus-rank knowledge blocks inappropriate lower fallbacks.

Version 1.0.2 offers Manual, Automatic and explicit imbue choices. Enhancement defaults to Automatic; Elemental/Restoration default to Manual. It adds out-of-combat and equipped-main-hand checks, preserves every existing temporary enchant, and leaves off-hand application manual. No proof of offhand weapon-versus-shield type or overwrite confirmation was found. The companion is unchanged. Offline cases cover selection, rank metadata, unavailable keys, temporary enchants and existing action priorities; no live cast or performance result is claimed.

## 16 November: current loader support for Fire Nova

Re-fetched the primary [Simia expression catalog](https://auth.simia.pro/rotation/expression-catalog.json), [native Forever shared expressions](https://auth.simia.pro/data/forever/_common.yaml), and [native Enhancement profile](https://auth.simia.pro/data/forever/rotation_7_ENHANCEMENT.yaml). The workspace retains these with timestamps/hashes in `research/native-20261116/sources.json`. This supersedes the original release's missing-position limitation.

The loader now documents owned minion `.up`, `.distance` (player center to newest copy), `.target_distance`, and `.enemies.N`. Searing ranks use NPC IDs 2523, 3902, 3903, 3904, 7400, 7402; Magma uses 5929, 7464, 7465, 7466. Missing summons return count zero and distance 1e9. Counts include enemy combat reach, use detected enemy nameplates, are not combat-filtered and ignore the AoE toggle. There is no documented `minion.ID.enemies.combat` expression.

Version 1.0.1's optional Nova checks one matching active totem/rank with at least 3 enemies within 10 yards. It explicitly requires AoE and keeps the totem within 20 yards; the surrounding 30-yard player-centered count must equal its combat-filtered count. This is a detected-enemy safeguard, not proof of no crowd control or unseen enemies. The native one-enemy/unknown-rank fallback is not copied. Preparation uses a stationary nearby pack, an empty fire slot or a tracked distant Searing/Magma, and combined setup/Nova/heal mana. No placement is inferred from a missing distance.

Water Shield already existed in all profiles. Enhancement's Lightning default explained the preference difference in source tests; 1.0.1 defaults all roles to Water while preserving explicit/saved choices. This does not establish the affected player's current binding or runtime state. The current host creates the ordinary Water Shield macro without a companion variant. No live combat or DPS simulation was performed for this update.

## Current rules that override older guides

- Lava Burst was removed. Its talent position became Call of Thunder (+5% Lightning Bolt/Chain Lightning critical chance). The active cooldown formerly called Elemental Mastery is now Lightning Mastery. Lightning Overload is 10/20/30%. Chain Lightning has a 2.5-second base cast and costs approximately 225% of the comparable Lightning Bolt rank. Riptide is now a 12-second-cooldown HoT with **no immediate heal**. Totemic Projection became Totemic Call, moves totems to the caster's location, and has a 30-second cooldown. [Blizzard, November 2 changes](https://us.forums.blizzard.com/en/wow/t/2360696/9).
- The November 10 Shaman adjustments actually went live November 12 at 18:45 UTC. Stormstrike is 100% weapon damage with an 8-second cooldown. Mental Dexterity grants 33/66/100% Intellect as attack power. Every Maelstrom Weapon rank now gives 20% cast-time and mana-cost reduction per stack; talent rank instead controls 6/7/8/9/10 procs per minute. Weapon imbues and weapon totems can operate together, explicitly including Windfury Weapon plus Windfury Totem. [Blizzard deployment confirmation](https://us.forums.blizzard.com/en/wow/t/wow-forever-hotfixes-november-11-2026/2403040/9), [official hotfix list](https://news.blizzard.com/en-us/article/24315281/wow-forever-hotfixes-november-11-2026).
- Persistent buff totems last five minutes; individual totems use a one-second global cooldown; short-duration totems remain short. Weapon imbues last 60 minutes. Water Shield is a talent, and only one elemental shield can be active. Rage of the Farseer is a personal melee-speed cooldown, not party Bloodlust. [Blizzard Shaman class deep dive](https://news.blizzard.com/en-us/article/24302097/world-of-warcraft-forever-class-deep-dives-mage-and-shaman). That older article's Lava Burst and direct-heal Riptide descriptions are superseded by November 2.

## Source precision and limitations

Local primary implementation inspected: `../research/mythicsim-engine`, previously recorded at commit `8e9b8df69ef9b27f16c23b51e1bb1686bd9f1d68`. The source implements Forever separately from its historical Go reference. Raw `data/spells.jsonl` still contains old names, obsolete abilities, duplicate creature/rune rows, and pre-hotfix numbers. Apply current official changes above; do not infer playable abilities just because a row exists.

Relevant implementation: [Shaman spell ladders](https://github.com/sage3648/mythicsim-forever-engine/blob/8e9b8df69ef9b27f16c23b51e1bb1686bd9f1d68/src/classes/shaman/prepare/spell_data.rs), [heals](https://github.com/sage3648/mythicsim-forever-engine/blob/8e9b8df69ef9b27f16c23b51e1bb1686bd9f1d68/src/classes/shaman/prepare/heals.rs), [shields](https://github.com/sage3648/mythicsim-forever-engine/blob/8e9b8df69ef9b27f16c23b51e1bb1686bd9f1d68/src/classes/shaman/prepare/shields.rs), [current-at-snapshot talent layout](https://github.com/sage3648/mythicsim-forever-engine/blob/8e9b8df69ef9b27f16c23b51e1bb1686bd9f1d68/src/classes/shaman/prepare/layout.rs), [totem geometry tests](https://github.com/sage3648/mythicsim-forever-engine/blob/8e9b8df69ef9b27f16c23b51e1bb1686bd9f1d68/tests/forever_totems_20261104.rs). These links identify locally inspected files; the GitHub pages were not independently fetched in this task.

The local snapshot predates November 12 Enhancement tuning. Historical fixture APLs, dual-wield fixtures, and the raw Lava Burst rows are not proof of current live recommendations. Current public MythicSim preset API requests were attempted but unavailable (web retrieval failure and local DNS failure); no current preset or numerical ranking is claimed. Healing fixtures use abstract party damage and self-targeted model spells, which must not be copied as live target selection.

## Verified bindings

These are **cast IDs**, except the explicitly labeled aura/talent. Resolve the highest actually learned rank for normal casts. Talent availability and totem quest completion are better gates than player level alone.

| Ability | IDs in rank order / notes |
|---|---|
| Lightning Bolt | 403, 529, 548, 915, 943, 6041, 10391, 10392, 15207, 15208 |
| Chain Lightning | 421, 930, 2860, 10605 |
| Earth Shock | 8042, 8044, 8045, 8046, 10412, 10413, 10414 |
| Flame Shock | 8050, 8052, 8053, 10447, 10448, 29228 |
| Frost Shock | 8056, 8058, 10472, 10473 |
| Stormstrike | 17364 |
| Maelstrom Weapon | Talent 408498; **player stack aura 408505**, maximum 5 |
| Lightning Mastery | 16166, renamed from Elemental Mastery |
| Rage of the Farseer | 425336 |
| Water Shield | 408510; do not bind mana-return effect 408511 |
| Lightning Shield | 324, 325, 905, 945, 8134, 10431, 10432 |
| Healing Wave | 331, 332, 547, 913, 939, 959, 8005, 10395, 10396, 25357 |
| Lesser Healing Wave | 8004, 8008, 8010, 10466, 10467, 10468 |
| Chain Heal | 1064, 10622, 10623 |
| Riptide | 408521, 1239242, 1239243 |
| Nature's Swiftness | 16188; 17116 is the Druid spell |
| Cure Poison / Cure Disease | 526 / 2870; Cure Disease 528 is Priest |
| Purge | 370, 8012 |
| Windfury Weapon | 8232, 8235, 10486, 16362; do not bind its triggered attack IDs |
| Flametongue Weapon | 8024, 8027, 8030, 16339, 16341, 16342 |
| Fire Nova | 408341, 408342, 408343, 408344, 408345; not Fire Nova Totem |
| Searing Totem | 3599, 6363, 6364, 6365, 10437, 10438 |
| Magma Totem | 8190, 10585, 10586, 10587 |
| Strength of Earth Totem | 8075, 8160, 8161, 10442, 25361 |
| Windfury Totem | 8512, 10613, 10614 |
| Grace of Air Totem | 8835, 10627, 25359 |
| Mana Spring Totem | 5675, 10495, 10496, 10497 |
| Healing Stream Totem | 5394, 6375, 6377, 10462, 10463 |
| Mana Tide Totem | 16190, 17354, 17359, 1325256 |
| Earthbind / Tremor / Grounding | 2484 / 8143 / 8177 |
| Poison / Disease Cleansing Totem | 8166 / 8170 |
| Totemic Recall | 36936 |
| Totemic Call | 437009, old row name Totemic Projection; live spellbook resolves the rename |

No verified live Forever evidence supports adding Wind Shear, Earth Shield, Lava Lash, Shamanistic Rage, Spiritwalker's Grace, Healing Rain, Healing Surge, Hex, Feral Spirit, or party Bloodlust/Heroism to these profiles. Omit them. Do not assume dual wield simply because the simulator accepts legacy fixtures for it.

## Shared mechanics and safeguards

- **Earth Shock is the interrupt.** Its local player row has the interrupt effect, 20-yard range, two-second school lockout and six-second shock-category cooldown. Flame/Frost Shock share that category. Rank 1 (8042) costs 30 mana in the captured client and is a sensible explicit interrupt binding if the loader can preserve its rank. If it automatically selects highest rank, describe that limitation rather than claiming rank-1 savings. Prefer an engaged hostile focus, then target. Do not interrupt protected crowd control or start a new fight.
- Maelstrom reduces **Lightning Bolt only**, not Chain Lightning or heals. Five stacks are instant and free at every current talent rank. A partially stacked bolt still requires standing still; do not treat the mere presence of the aura as permission to cast while moving.
- Stormstrike's captured row has one charge lasting 12 seconds, increasing the casting Shaman's next Lightning Bolt, Chain Lightning, or Earth Shock by 20%. Do not treat it as a blanket party Nature-damage buff. A ready Stormstrike can precede a five-stack Bolt if melee access is assured; do not hold a capped/expiring Maelstrom indefinitely waiting for it. Its latest cooldown is eight seconds.
- Lightning Mastery is a 15-second, three-minute cooldown that shortens Lightning Bolt by 0.5 seconds and removes Chain Lightning's cooldown. It does not grant an instant cast, free mana, or a guaranteed critical strike. Movement rules still apply.
- Water Shield has three globes, ten-minute duration, no mana cost, and no actual cooldown in the inspected Forever implementation. Each globe returns 2% maximum mana from incoming attacks or the Shaman's critical spells, subject to a 3.5-second internal limit. Prefer it for mana sustainability when learned; otherwise maintain Lightning Shield for solo damage. Refresh a missing/depleted shield; do not alternate the two on every evaluation.
- Totems occupy elemental slots. Never overwrite an active Mana Tide with Mana Spring, Healing Stream, or cleansing maintenance. Likewise, preserve manually selected Tremor/Grounding/resistance totems rather than repeatedly replacing them with damage buffs. Place long-lived utility totems when a pull merits their mana cost; short solo kills do not need a full four-totem setup.
- Fire Nova erupts within 10 yards of the **active fire totem**, while Magma's damage radius is 8 yards. Enemy count around the player is not enough to validate either. Check totem presence, location, engaged enemies and crowd control, or leave ambiguous placement manual. Totemic Call now pulls totems to the player; it cannot project them onto a distant ranged target. Totemic Recall destroys existing totems and returns 25% of their original mana costs; use between pulls when leaving, not as routine in-combat mana generation.
- Use range and line-of-sight checks for all heals, interrupts and dispels. Use health deficits, urgency and incoming healing when available. Suppress cast-time actions while moving, except an actually active Nature's Swiftness for an eligible heal or five-stack Maelstrom for Lightning Bolt. Avoid spending Nature's Swiftness on an offensive spell while an emergency heal is pending.

## Recommended leveling and normal-dungeon policy

The priorities below are engineering recommendations inferred from the verified mechanics, not simulated optima. Health/mana thresholds and expected target lifetime should be exposed as settings rather than presented as universal best values.

### Elemental

1. Emergency self/party rescue, dangerous interrupt and needed poison/disease removal take precedence. Save enough mana for a heal and interrupt.
2. Maintain the selected shield and an appropriate weapon imbue without repeatedly recasting. Flametongue is a safe non-Rockbiter melee fallback; do not assume it supplies a retail-style spell-power bonus.
3. While stationary, Lightning Bolt is the economical baseline. Add Chain Lightning for two or more safe, clustered engaged enemies with sufficient mana. Single-target Chain Lightning is an optional burst choice, not the default mana-saving leveling filler.
4. Use Flame Shock when its remaining lifetime will be useful, particularly while moving; do not clip an existing own DoT simply to fill every moving global. Earth Shock is an instant finisher or moving filler only when interrupt reservation and mana permit. Frost Shock is primarily a needed slow, not unconditional dungeon damage.
5. Lightning Mastery belongs on meaningful stationary fights or a safe multi-target burst window with mana available. Do not enable continuous expensive Chain Lightning merely because its cooldown disappears.
6. Searing for sufficiently long stationary fights; Magma/Fire Nova only after safe totem positioning is verified. Allow movement downtime instead of failing cast-time spells or spending all remaining mana on shocks.

### Enhancement

1. Preserve survival and interrupt access; maintain melee autoattacks when in range and facing. Windfury Weapon is preferred once learned; use Flametongue before it in dungeons. Rockbiter has threat implications, especially with Spirit Weapons. Version 1.0.2's named Automatic leveling option (the Enhancement default) explicitly includes Rockbiter only until Flametongue or Windfury is trained; it does not infer a separate dungeon preference. Grouped DPS who want to exclude Rockbiter should select explicit Flametongue once learned, then Windfury when trained. Any existing Rockbiter enchant is still preserved: remove it manually or let it expire before the chosen replacement can apply.
2. Use Stormstrike in melee; spend five-stack Maelstrom on Lightning Bolt, with the short Stormstrike setup described above when reliable. Avoid ordinary hardcast Lightning Bolt in melee as default, since this sacrifices swings and exposes the player to pushback. A stationary ranged opener before contact remains useful.
3. Use a worthwhile Flame Shock, then Earth Shock for damage when interrupts are not being reserved and mana allows. A low-mana mode should retain autoattacks, free Maelstrom Bolts and essential survival while reducing shocks, damage totems and other discretionary spells.
4. Rage of the Farseer requires sustained melee access and a target expected to survive. Windfury Totem is now compatible with Windfury Weapon; maintain it on worthwhile pulls when no higher-priority air utility is needed.
5. On the move, melee attacks, Stormstrike, five-stack Bolt and eligible shocks work; shorter partial-stack Bolts still require stopping. Do not use Chain Lightning as a Maelstrom spender.

### Restoration

1. Select a living friendly unit needing healing, including the player and all party members. Treat imminent death before maintenance or damage; prioritize the tank under continuing pressure without ignoring a critically injured other member.
2. Use Nature's Swiftness plus Healing Wave for a real emergency, including movement. Keep the same intended recipient through both actions. Without that instant effect, stop moving for Lesser Healing Wave when speed matters; use Healing Wave for a larger, non-immediate deficit. Before Lesser Healing Wave is learned, Healing Wave remains the fallback.
3. Riptide is a useful moving HoT and preparatory heal on a target likely to take ongoing damage. It is **not** a direct emergency rescue. Chain Heal receives a 25% increase on its direct target when that target has the Shaman's own Riptide; the model does not consume the HoT. Do not insist on Riptide setup when someone needs immediate healing.
4. Chain Heal is for injured allies within jump distance. A count of injured party members alone does not prove they are clustered. Without reliable proximity, prefer single-target healing. Do not spam it merely because mana exceeds a fixed percentage.
5. Use Cure Poison or Cure Disease only for matching, removable effects; Shaman is not assumed to have a generic friendly magic/curse dispel. Purge is hostile magic removal and belongs behind healing emergencies, with a relevant-buff gate.
6. Maintain Water Shield when talented. Use Mana Tide during sustained demand, while recipients can benefit and enough time remains for pulses; do not wait for zero mana. Choose Mana Spring for sustained mana needs or Healing Stream for useful continuing group damage, respecting their shared water slot.
7. Solo damage uses the same conservative Lightning Bolt/Flame Shock policy as Elemental, with self-healing first. Dungeon damage is optional only while the party is safe and mana is comfortable; interrupting a dangerous cast can be more valuable than another damage spell.

## Level coverage checkpoints

Captured spell rows identify these first ranks: Lightning Bolt/Healing Wave at 1; Earth Shock at 4; Lightning Shield at 8; Flame Shock/Flametongue Weapon/Searing at 10; Fire Nova/Purge/Ancestral Spirit at 12; Cure Poison at 16; Lesser Healing Wave/Healing Stream/Totemic Recall at 20; Cure Disease/Totemic Call at 22; Magma/Mana Spring at 26; Windfury Weapon/Grounding at 30; Chain Lightning/Windfury Totem at 32; Chain Heal and Riptide's first rank at 40. Totem quests, training and talents can delay actual access.

Milestone talent gates are separate: Water Shield needs 11 Restoration points; Mana Tide is a 16-point Restoration milestone; Nature's Swiftness is a 21-point Restoration milestone; Riptide and Lightning Mastery/Rage of the Farseer are their 31-point tree capstones. Stormstrike moved to the earlier Enhancement milestone; do not let its stale raw `SpellLevel=40` block an already learned spell. Every action must gracefully skip unlearned spells and retain the low-level filler/heal fallback.
