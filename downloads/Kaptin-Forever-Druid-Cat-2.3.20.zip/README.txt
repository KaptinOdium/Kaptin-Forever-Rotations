Forever Druid - Cat 1-60 | 2.3.20

Copy 11_cat.yaml into your Simia Forever loader's forever/custom folder. Refresh the rotation list and select Forever Druid - Cat 1-60 version 2.3.20.

Keep Cat selected in Simia and switch forms in WoW. Cat uses Cat attacks. Bear and Dire Bear use Bear attacks. To control every shift, disable automatic form entry under Feral. Automatic Mark of the Wild, Thorns and caster heals wait until you leave Travel or Aquatic Form.

Bind ordinary Lacerate, Primal Bite, Maul and Swipe as you learn them. On an engaged enemy expected to live at least six seconds, or with unknown remaining life, Bear builds your Lacerate to five stacks and refreshes when 4.5 seconds or less remain. At five healthy stacks, it uses Primal Bite on one enemy, or Maul if Bite is unlearned or disabled and rage allows. With AoE on and at least two nearby enemies already in combat, it favors Swipe. Automatic Swipe waits if another idle enemy is in range.
