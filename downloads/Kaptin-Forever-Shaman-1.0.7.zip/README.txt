KAPTIN FOREVER SHAMAN 1-60 - version 1.0.7
20 November 2026

ENHANCEMENT 1.0.7
Under Enhancement, enable Spend Clearcasting on Chain Lightning in packs
(Deac). The option starts off. Bind ordinary Chain Lightning, enable
Damage > Chain Lightning for engaged packs, and turn AoE on. With an
Elemental Focus proc and three engaged enemies by default, the profile
tries Chain Lightning before Fire Nova and damage shocks. Stand still
for a hardcast. A ready five-stack instant Maelstrom Bolt takes priority.

Routine Magma requires the Magma-on-packs Fire slot and an available
Magma Totem bind. With default settings, stand still in combat with a
target within 8 yards and three fighting enemies within 8 yards of you.
It waits for 35% mana and a target expected to live 10 seconds, or 70%
target health when the estimate is unknown. Idle enemies within 20 yards
block the drop. An active Searing that still reaches enemies keeps its slot.

RESTORATION 1.0.6
Restoration has its own Main-hand weapon imbue (Manual), Air slot (None),
group healing (on) and group cures (on). Recheck these four choices once
after upgrading. Enable Windfury Weapon or Windfury Totem separately if
you want either. An existing weapon enchant lasts until it expires.

ENHANCEMENT 1.0.5
Reload Forever Shaman - Enhancement 1-60. Under Totems, enable routine
totems and select Searing or Magma on packs with Searing otherwise for
the Fire slot. Bind the ordinary Searing Totem spell. With AoE off,
Searing can drop for a lone, engaged enemy within 20 yards once the
movement, mana and fight-length settings allow it.

Recast selected totems that have fallen out of range is on by default.
During an eligible fight, stop moving to replace a tracked support totem
more than 30 yards from you. Other slots stay in place. For Searing and
Magma, the profile checks whether the old totem can still reach the
selected enemy or has other enemies nearby. If Simia cannot locate an
active totem, you can move or replace it manually. Totemic Recall is manual.

AIR TOTEM UPDATE
Air-slot availability now checks which totems are active. An unrecognized
legacy totem name no longer needs to report itself as absent before Windfury
can be considered. Detected Grounding and other air totems remain protected.
This closes an offline-reproduced skip path; Deac's live cause is unconfirmed.
Reload the updated YAML. No new key, setting or companion update is needed.

ENHANCEMENT PRIORITY
When both are eligible, Windfury Totem now comes before Strength of Earth.
Reactive Grounding still has priority. Strength remains available afterward,
and an unavailable Windfury does not prevent eligible lower-priority actions.
Totems > Air slot must be Windfury (the Enhancement default) and its ordinary
key must be bound. Mana, fight-length, movement, occupied-slot and healing
reserve checks are unchanged. Elemental/Restoration priorities are unchanged.
Reload the updated Enhancement profile; no new setting or addon update needed.

Three Simia profiles for WoW Forever solo questing and normal dungeons:
  Forever Shaman - Elemental 1-60
  Forever Shaman - Enhancement 1-60
  Forever Shaman - Restoration 1-60

The matching binding companion is KaptinForeverShamanBindings 1.0.1.
This release uses the current Forever class rules, including November 12's
Enhancement changes. It is not a Retail, TBC or Wrath rotation.

INSTALL AND SELECT
1. Copy the three files from forever/custom into your Simia loader's
   forever/custom folder.
2. Copy Interface/AddOns/KaptinForeverShamanBindings into your Forever
   client's Interface/AddOns folder. Enable it alongside Simia on the Shaman.
   Restart WoW if the new addon is not listed.
3. Select the desired Shaman profile in the loader. Reload the selected
   profile after replacing its YAML file.
4. Type /kaptinshamanbindings to inspect the companion's host connection.
5. For group healing/cures, open Keybinds > AutoBind > Focus binds and select
   Party (player + party1-4), or Raid to cover dungeons and raids. Forever defaults to Off;
   selecting a healing rotation does not enable this setting. Repeat for
   each talent group you use for healing.
6. Click the top AUTOBIND row and confirm, or assign keys individually.
   Selecting a keyboard layout or focus scope alone does not run AutoBind.
   Verify the shared Focus Player/Party (and Raid, when selected) keys, each
   required heal/cure @focus key, and the separate self-heal @player keys.
   Test an injured teammate, then reload and check again before relying on
   group healing. Simia handles focus changes. /kaptinshamanbindings shows
   the current route and lists any missing shared assignment keys.
7. Under Buffs > Main-hand weapon imbue, choose Automatic leveling or a
   specific imbue and bind its ordinary spell row. Enhancement defaults to
   Automatic; Elemental/Restoration default to Manual. Test out of combat
   with an unenchanted main-hand weapon. Existing temporary enchants stay.

If the log reports a heal @party1-4 - NO BIND, the loader is requesting
direct party keys. To keep Focus binds Off for a dungeon, right-click each
learned group heal/cure in Keybinds > Autobind > Additional Macros and add
@party1, @party2, @party3 and @party4. Check each assigned key. For Party or
Raid focus scope, verify the shared assignment and per-spell @focus keys.

The share ZIP contains only three profiles, the addon's Lua/TOC files and four
documents. It contains no images, personal settings or old host patches.
The workspace build also prepares an optional install.ps1 and manifest, kept
outside the share ZIP. That installer is restricted to eight destination
files: these three profiles in each of the current and legacy loader roots,
plus the addon's two files. It checks source and existing-file hashes, backs
up replaced files and attempts rollback on failure. Preparing a package does
not run this installer or install anything. Its manifest must be regenerated
after changing package sources or reviewed installed files.

MOVEMENT AND TARGETING
You control movement, facing and target selection. Hardcasts wait until
you stop. Eligible instant actions can work while moving.
Select and engage an enemy yourself unless you deliberately enable the
option allowing a pull on your idle selected enemy.

By default, Earth Shock may cancel your Lightning Bolt or Chain Lightning to
interrupt an eligible enemy cast. Disable that option to preserve those damage
casts too. Your healing casts remain protected. The Ghost Wolf preservation
toggle holds normal rotation actions while you remain in that form.
There are no added line_cd pauses or timed rotation loops. Low mana, movement,
an invalid target, a missing binding or a healing emergency can legitimately
leave no eligible damage action. A setting being enabled does not establish
that its key is assigned or works in game.

Learned-spell checks provide low-level fallbacks. The package does not train
spells, complete totem quests, spend talent points or create missing abilities.
Check new bindings after training, talent changes or respecializing.

ROLE BEHAVIOR
Elemental uses Lightning Bolt as its stationary filler, worthwhile Flame
Shocks, optional mobile Earth Shock and mana-gated Chain Lightning on engaged
packs. Lightning Mastery needs a stationary damage window; it does not make
Lightning Bolt instant or free. Lava Burst was removed and is not used.

Enhancement uses melee attacks, Stormstrike and instant Lightning Bolt when
Maelstrom allows it. Five current Maelstrom stacks affect Lightning Bolt only,
not Chain Lightning or healing spells. Partial stacks do not grant mobile
casting. Hardcast ranged opening is a separate choice; the profile never runs
into melee for you. Main-hand imbue maintenance defaults to Automatic:
Rockbiter until Flametongue is trained, then Windfury once trained (normally
level 30). Windfury Weapon and Windfury Totem can work together under the
current Forever hotfix.
Rage of the Farseer is used on durable fights while already in melee, when
offensive cooldowns are enabled.

Restoration prioritizes healing over damage and can heal without an enemy
selected. Nature's Swiftness can enable emergency Healing Wave; otherwise
cast-time heals require stopping. Riptide is a HoT with no initial direct
heal. Chain Heal uses injured-member counts as a heuristic: the reader cannot
measure ally-to-ally bounce distances. Disable that option when the party is
spread out. Group healing uses the direct party or focus keys for the selected
route. Missing keys can leave the healer waiting while an ally needs recovery.

SHARED SUPPORT
Self-healing, learned shields, poison/disease cures, mana reserves and optional
potions support leveling. The hurt-player mana reserve is based on a Healing
Wave cost; thresholds remain adjustable. Water Shield is preferred for mana
when learned in all three profiles, with Lightning Shield as the unlearned
fallback. Existing saved choices are preserved: under Buffs, enable shield
maintenance and choose Personal shield preference > Water Shield (mana).
Check that the ordinary Water Shield action is learned, enabled and bound.
A missing/depleted shield is refreshed; it does not replace remaining charges.
The package
does not alternate elemental shields on every evaluation.

Earth Shock supplies the interrupt. It shares cooldown with Flame Shock and
Frost Shock. The profile can reserve shocks during a cast or reserve them
entirely for interrupts. The ordinary host binding resolves learned ranks;
this package does not promise rank-one interrupt mana savings. Optional
mouseover interrupts require their own key and an engaged valid hostile unit.
There is no Wind Shear binding. Purge is hostile magic removal, not a friendly
magic cleanse. Friendly cures cover poison and disease.

TOTEMS AND MANUAL TOOLS
Configure only totems you want maintained, and verify that an existing totem
is recognized before relying on maintenance. Routine slot guards preserve
recognized utility totems, including Mana Tide. Enabled
Mana Tide and Grounding can intentionally replace the water and air totem,
respectively, when their conditions are met.
Recognition still depends on live host telemetry; repeated deployment means
maintenance should be disabled until that is resolved.

The current loader exposes tracked totem positions and nearby enemy counts.
These counts use detected enemy nameplates and cannot prove freedom from
crowd control or account for undetected enemies.
Damaging totems and Chain Lightning require appropriate player positioning
and encounter judgment; disable them around protected targets or risky packs.

Off-hand imbues, Totemic Call, Totemic Recall, Earthbind, Tremor,
resistance and cleansing totems remain manual tools. There is no automatic
totem twisting. Totemic Call now moves totems to your feet, not to a distant
cursor location. Fire Nova erupts around the active fire totem. Grounding is
an optional utility setting; decide when replacing the air slot is desirable.
Routine water-totem maintenance is designed to preserve an active Mana Tide.

MAIN-HAND WEAPON IMBUE
Buffs > Main-hand weapon imbue offers Manual, Automatic leveling, Windfury,
Flametongue, Rockbiter and Frostbrand. Automatic uses the highest trained
choice in the Windfury > Flametongue > Rockbiter order, not character level
alone. Elemental and Restoration stay Manual unless you enable a choice.

It applies only outside combat, with a main-hand item and no active temporary
enchant. Any existing temporary enchant is kept, even a different imbue, oil
or sharpening stone. To switch an active enchant, let it expire or remove it
yourself. There are no overwrite-confirmation clicks or off-hand casts.
Food, drink, Ghost Wolf, casts and healing priorities remain protected.

Bind the ordinary chosen spell. A learned preferred imbue with no usable key
does not fall back to another enchant; repair its binding or select another
choice. No new companion or weapon-slot macro is required. Off-hand remains
manual because the exposed equipment checks cannot distinguish its weapon
from a shield reliably. The native casting route is source-verified; this
release still needs live confirmation of your weapon enchant detection.

OPTIONAL FIRE NOVA
In the profile's Fire Nova section, enable Use Fire Nova on packs around
your fire totem. It is OFF by default. Bind the ordinary Fire Nova action,
keep the loader AoE toggle ON, and use a current loader with minion tracking.

The default is 3+ detected enemies inside a tracked Searing/Magma totem's
10-yard blast, with that totem within 20 yards of you. It checks the actual
totem-centered count, not a sum across totem ranks. All detected enemies
within 30 yards of you must be in combat. Unknown ranks or unavailable
position/count data skip Nova; there is no slot-only firing fallback.

Default mana threshold is 40%, target lifetime 6 seconds (or high health
when lifetime is unknown). Your reserved self-heal mana is kept. Healing
and interrupts run first. Restoration also requires safe group health and
its normal damage mana threshold. Enhancement preserves a ready, instant
five-stack Maelstrom Bolt before spending a global on Nova/setup.

For automatic setup, leave Place the selected fire totem enabled, enable
routine totems, and select a Fire slot under Totems. A stationary pack of
3+ combat enemies within 8 yards can trigger setup. The pack choice uses
Magma, or Searing if Magma is unlearned/blocked; the Searing choice uses
Searing. Mana must cover the drop, Nova and your reserved heal, while staying
above the Nova/Restoration damage mana floor after the totem is placed.

The enabled replacement option can replace a tracked Searing/Magma left
over 20 yards away. Existing nearby totems, utility fire totems and unknown
positions are preserved. After dropping, Nova waits for positive tracking
and a qualifying blast count. Totemic Call stays manual.
Disable Fire Nova around crowd-controlled mobs; combat status alone cannot
identify them. Offline-tested only; live casting still needs verification.

POTIONS AND BINDINGS
Bind the native Health Potion and, if enabled, Mana Potion actions. The
companion provides level-appropriate Classic potion fallbacks through the
host's existing rebuild function. Your explicit potion lists and custom
macros keep precedence. It refreshes generated buttons on existing keys
outside combat; it does not allocate keys. Supply usable potions yourself.

VALIDATION LIMITS
The package builder checks release versions, the exact archive file list and
byte-for-byte agreement with its sources. Offline profile scenarios and Lua
binding tests are separate workspace checks. None of these demonstrates live
key delivery, native group focus transport, current-character spell learning,
totem recognition, real Chain Heal bounces or successful in-game casting.
No DPS simulation or measured leveling-speed comparison was run for this
release. There is no claim of a universally optimal rotation. RESEARCH.md
records class sources, current mechanics and evidence limitations.
