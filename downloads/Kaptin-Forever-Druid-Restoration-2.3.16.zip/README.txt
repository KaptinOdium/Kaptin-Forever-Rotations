Restoration Druid 2.3.16 for Simia Forever

1. Copy 11_restoration.yaml into the loader's forever/custom folder.
2. Copy KhanForeverBindings into WoW Forever's Interface/AddOns folder, enable it, then /reload. Reload the profile list in Simia and select Restoration 2.3.16.
3. In a dungeon, select Keybinds > AutoBind > Focus binds > Party and run AUTOBIND. Verify the shared Focus Party 1-4 keys and Swiftmend @focus. Simia assigns the focus automatically when healing. In a raid choose Raid and verify its assignment keys. If you keep Focus binds Off in a dungeon, assign Swiftmend @party1 through @party4 instead.
4. To check the cast, leave an enemy selected while your own Rejuvenation or Regrowth is active on a nearby ally at or below the Swiftmend effective-health setting. With Swiftmend learned and ready and enough mana, check the in-game combat log for Swiftmend and the ally's name. Incoming heals count toward effective health.
