Restoration Druid 2.3.17 for Simia Forever

1. Copy forever/custom/11_restoration.yaml into the loader's forever/custom folder. Reload the rotation list and select Restoration 2.3.17.
2. If you already have KhanForeverBindings 1.1.7, keep it. For a new install or an older version, copy the included KhanForeverBindings folder into WoW Forever's Interface/AddOns folder, enable the addon, then /reload.
3. For battlegrounds, choose Keybinds > AutoBind > Focus binds > Raid. Run AUTOBIND out of combat and confirm. Run /khanbindings swiftmend to check the Swiftmend and Rejuvenation @focus bindings and the shared raid-slot keys. For dungeon parties, Party scope and its shared party-slot keys also work.

With Swiftmend ready and enough mana for both spells, an injured teammate missing your Rejuvenation and Regrowth can receive Rejuvenation at your Swiftmend threshold. Emergency direct heals take priority. On the next healing decision, Swiftmend checks for your HoT on an ally still within range and at or below the effective-health threshold.

To isolate the new behavior, temporarily set routine Rejuvenation to 50% and Swiftmend to 80%. Leave an enemy selected or clear your target. Watch a nearby non-tank teammate around 75% effective health who has neither of your HoTs. With no higher-priority heal needed, look for your Rejuvenation and then Swiftmend on that teammate in WoW's combat log. If the teammate recovers above the threshold after the first cast, Swiftmend waits. Restore your usual sliders after testing.
